class CuentaBancaria:
    def __init__(self, titular, saldo):
        self.__titular = titular
        self.__saldo = saldo
    def depositar(self, cantidad):
        self.__saldo += cantidad
    def retirar(self, cantidad):
        if cantidad > self.__saldo:
            print("No se puede retirar esa cantidad. Saldo insuficiente.")
        else:
            self.__saldo -= cantidad
    def mostrar_saldo(self):
        print(f"Saldo de la cuenta: {self.__saldo}")
cuenta = CuentaBancaria("Juan Pérez", 1000)
cuenta.mostrar_saldo()  # Acceso público al método "mostrar_saldo"
cuenta.depositar(500)  # Acceso público al método "depositar"
cuenta.mostrar_saldo()  # Acceso público al método "mostrar_saldo"
cuenta.retirar(200)  # Acceso público al método "retirar"
cuenta.mostrar_saldo()  # Acceso público al método "mostrar_saldo"
print(cuenta.__saldo)  # Acceso privado (incorrecto) a través del nombre del atributo
