class Pelicula:
    def __init__(self, titulo, director):
        self.titulo = titulo
        self.director = director
    def mostrar_informacion(self):
        print(f"Título: {self.titulo}")
        print(f"Director: {self.director}")
pelicula1 = Pelicula("El Padrino", "Francis Ford Coppola")
print(pelicula1.titulo) 
pelicula1.director = "Francis Coppola" 



