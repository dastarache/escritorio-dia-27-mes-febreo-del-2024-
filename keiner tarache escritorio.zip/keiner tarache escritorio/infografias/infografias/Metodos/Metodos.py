class telefono :
    def __init__(self, marca, modelo, año):
        self.marca = marca
        self.modelo = modelo
        self.año = año
    def encender(self):
        print("El telefono ha encendido ")
    def mostrar_pantalla(self):
        print("El telefono muestra una interfaz")
    def apagar_telefono(self):
        print("El telefono se esta apagando")
    def cambiar_marca(self, nueva_marca):
        self.marca = nueva_marca
        print("La marca del telefono ha sido cambiada a", nueva_marca)
samsung=telefono("samsung", "A20", 2020)
samsung.cambiar_marca("iphone")
print(samsung.marca)  # salida: iphone
