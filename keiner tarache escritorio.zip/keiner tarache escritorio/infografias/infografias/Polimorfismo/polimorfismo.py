class Animal:
    def hacer_sonido(self):
        pass
class Perro(Animal):
    def hacer_sonido(self):
        return "Woof!"
class Gato(Animal):
    def hacer_sonido(self):
        return "Meow!"
def sonido_animal(animal):
    return animal.hacer_sonido()
perro = Perro()
gato = Gato()
print(sonido_animal(perro))
print(sonido_animal(gato))   
