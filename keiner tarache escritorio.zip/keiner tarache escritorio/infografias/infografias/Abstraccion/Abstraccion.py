class Libro:
    def __init__(self, titulo, autor, fecha_publicacion):
        self.titulo = titulo
        self.autor = autor
        self.fecha_publicacion = fecha_publicacion
    def obtener_titulo(self):
        return self.titulo
    def obtener_autor(self):
        return self.autor
    def obtener_fecha_publicacion(self):
        return self.fecha_publicacion
#libro1 = Libro("harry potter", " J.K. Rowling", "26 de junio de 1997")
#print(libro1.obtener_titulo())
#print(libro1.obtener_autor())
#print(libro1.obtener_fecha_publicacion())
