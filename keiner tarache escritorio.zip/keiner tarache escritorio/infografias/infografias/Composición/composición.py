class cargador:
    def __init__(self,carga ):
        self.carga=carga 
            
    def bateria (self):
        if self.carga=="cargando": 
            print ("el telefono esta cargando ")
            
class telefono : 
    def __init__(self, estado ,carga ):
        self.estado=estado
        self.telefono = cargador(carga)
    def cargando(self):
        self.telefono.bateria()
        
        
objeto=telefono("bateria_baja", "cargando")
objeto.cargando()
