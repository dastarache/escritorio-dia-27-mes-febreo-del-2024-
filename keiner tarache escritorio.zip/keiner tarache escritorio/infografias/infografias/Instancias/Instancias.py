class Animal:
    def __init__(self, nombre, especie):
        self.nombre = nombre
        self.especie = especie
mascota = Animal("dante ", "Perro")
print(mascota.nombre)
print(mascota.especie)

