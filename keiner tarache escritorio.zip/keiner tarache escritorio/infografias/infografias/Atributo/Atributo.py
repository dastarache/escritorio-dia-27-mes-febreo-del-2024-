class Persona:
    def __init__(self, nombre):
        self.nombre = nombre
    def obtener_nombre(self):
        return self.nombre
class Estudiante(Persona):
    def __init__(self, nombre, universidad):
        super().__init__(nombre)
        self.universidad = universidad
    def obtener_universidad(self):
        return self.universidad
mi_estudiante = Estudiante("Juan", "Universidad:  unillanos")
print(mi_estudiante.obtener_nombre())
print(mi_estudiante.obtener_universidad())
    