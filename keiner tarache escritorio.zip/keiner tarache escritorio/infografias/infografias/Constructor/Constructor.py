class cursos:
    def __init__(self, nombre ,creditos , profesion ):
        self.nombre  = nombre 
        self.creditos = creditos
        self.profesion = profesion
curso1= cursos("matematicas ", "3","asessino" )
print(curso1.nombre)
curso2= cursos("español ", "3","asessino" )
print(curso2.nombre)