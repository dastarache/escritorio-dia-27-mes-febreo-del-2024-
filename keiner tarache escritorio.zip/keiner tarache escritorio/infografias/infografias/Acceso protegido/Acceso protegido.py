class Animal:
    def __init__(self, nombre):
        self._nombre = nombre
    def _comer(self):
        print("El animal está comiendo.")
class Perro(Animal):
    def __init__(self, nombre, raza):
        super().__init__(nombre)
        self._raza = raza
    def ladrar(self):
        print("¡Guau guau!")
perro = Perro("ronald", "chandoverman")
print(perro._nombre)  # Acceso protegido al atributo "_nombre"
perro._comer()  # Acceso protegido al método "_comer"
perro.ladrar()  # Acceso público al método "ladrar"
