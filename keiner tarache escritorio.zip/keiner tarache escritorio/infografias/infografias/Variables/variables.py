class Persona:
    nombre = "Juan"
    edad = 30
    def obtener_info(self):
        return f"Persona: {self.nombre}, {self.edad} años"
mi_persona = Persona()
print(mi_persona.obtener_info())
