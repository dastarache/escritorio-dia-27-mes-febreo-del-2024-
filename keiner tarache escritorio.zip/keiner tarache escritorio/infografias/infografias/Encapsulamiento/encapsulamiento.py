class Cuadrado:
    def __init__(self, lado):
        self._lado = lado
    def get_area(self):
        return self._lado * self._lado
cuadrado = Cuadrado(4)
print(cuadrado.get_area())

