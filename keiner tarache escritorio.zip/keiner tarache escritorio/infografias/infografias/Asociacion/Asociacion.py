class Libro:
    def __init__(self, titulo, autores):
        self.titulo = titulo
        self.autores = autores
class Autor:
    def __init__(self, nombre):
        self.nombre = nombre
        self.libros_escritos = []
    def escribir_libro(self, libro):
        self.libros_escritos.append(libro)
