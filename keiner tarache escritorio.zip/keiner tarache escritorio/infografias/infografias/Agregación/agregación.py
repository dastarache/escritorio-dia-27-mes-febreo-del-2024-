class Rueda:
    def __init__(self, modelo):
        self.modelo = modelo
class Bicicleta:
    def __init__(self, marca):
        self.marca = marca
        self.ruedas = []  # Lista para almacenar las ruedas
    def agregar_rueda(self, rueda):
        self.ruedas.append(rueda)
rueda_delantera = Rueda("Delantera")
rueda_trasera = Rueda("Trasera")
mi_bicicleta = Bicicleta("MarcaX")
mi_bicicleta.agregar_rueda(rueda_delantera)
mi_bicicleta.agregar_rueda(rueda_trasera)
print(f"Bicicleta: {mi_bicicleta.marca}")
print("Ruedas:")
for rueda in mi_bicicleta.ruedas:
    print(f"Modelo: {rueda.modelo}")
