class Producto:
    def __init__(self, nombre, precio):
        self.nombre = nombre
        self.precio = precio
    def mostrar_informacion(self):
        print(f"Producto: {self.nombre}")
        print(f"Precio: {self.precio}")
class CarritoCompras:
    def __init__(self):
        self.productos = []
    def agregar_producto(self, producto):
        self.productos.append(producto)
    def mostrar_carrito(self):
        print("Productos en el carrito:")
        for producto in self.productos:
            producto.mostrar_informacion()
producto1 = Producto("Camiseta", 25.99)
producto2 = Producto("Pantalón", 39.99)
carrito = CarritoCompras()
carrito.agregar_producto(producto1)
carrito.agregar_producto(producto2)
carrito.mostrar_carrito()
