class Vehiculo:
    def __init__(self, marca):
        self.marca = marca
    def obtener_info(self):
        return f"Vehículo de la marca {self.marca}"
class Coche(Vehiculo):
    def __init__(self, marca, modelo):
        super().__init__(marca)
        self.modelo = modelo
    def obtener_info(self):
        return f"Coche {self.modelo} de la marca {self.marca}"
mi_coche = Coche("Toyota", "Corolla")
print(mi_coche.obtener_info())
