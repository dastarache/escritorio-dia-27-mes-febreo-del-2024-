

class MiClase:
    SALARIO_MINIMO = 10000000  
    def metodo1(self):
        return 0
    def metodo2(self):
        return 1
    def metodo2_1(self):
        numero = int(input("Agrega un número: "))
        return numero
    def metodo3(self):
        a = self.metodo1()
        b = self.metodo2()
        c = self.metodo2_1()
        salario = a + b + c
        if salario >= self.SALARIO_MINIMO:
            mensaje = "¡Felicidades! Ganas más del salario mínimo."
        else:
            mensaje = "Ganas menos del salario mínimo."
        return salario, mensaje
    def savePalabra(self, mensaje, b):
        f = open(b + ".txt", "w")
        f.write(mensaje)
        f.close()
    def bucle(self):
        contador_archivos = 0
        for i in range(1, 11):
            self.savePalabra("Archivo " + str(i), "archivo" + str(i))
            contador_archivos += 1
            print("se creo ", contador_archivos)
# ------------------------------
nuevaInstancia = MiClase()
# Descomenta las líneas que quieras probar
# nuevaInstancia.metodo2_1()
# nuevaInstancia.metodo3()
# nuevaInstancia.savePalabra("oh gloria","arroz")
nuevaInstancia.bucle()
