import random

class MiClase:
    def __init__(self, documento, saldo_inicial):
        self.documento = documento
        self.__saldo = saldo_inicial

    def settSaldo(self, newSaldo): 
        self.__saldo = newSaldo 
    def gettSaldo(self):
        return self.__saldo
    def retiro(self, saldoRetirado):
        if saldoRetirado > self.__saldo: 
            self.impriir("No tienes suficiente dinero")
        else:
            descuento = saldoRetirado * 0.05  
            saldo_restante = self.__saldo - saldoRetirado  
            saldo_restante -= descuento 
            self.__saldo = saldo_restante  
    def verSaldo(self): 
        print(f"Saldo actual para {self.documento}: {self.__saldo}")
    def impriir(self, mensaje):
        print(mensaje)
u =[]
persona1 = MiClase("123", 1000)
u.append(persona1)
u[0].verSaldo()
monto_retiro = int(input("Ingrese la cantidad a retirar: "))
u[0].retiro(monto_retiro)
u[0].verSaldo()
