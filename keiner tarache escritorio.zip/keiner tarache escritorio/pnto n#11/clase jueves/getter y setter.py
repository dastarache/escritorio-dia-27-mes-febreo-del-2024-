import random

class MiClase:
    def __init__(self):
        self.documento = random.randint(1, 100)
        self._saldo = random.randint(1, 1000)
        self.SALARIO_MINIMO = 10000000  
    def metodo1(self):
        return 0
    def metodo2(self):
        return 1
    def metodo2_1(self):
        numero = float(input("Agrega un número: ")) 
        return numero
    def metodo3(self):
        a = self.metodo1()
        b = self.metodo2()
        c = self.metodo2_1()
        salario = a + b + c
        if salario >= self.SALARIO_MINIMO:
            mensaje = "¡Felicidades! Ganas más del salario mínimo."
        else:
            mensaje = "Ganas menos del salario mínimo."
        return salario, mensaje
    def savePalabra(self, mensaje, b):
        with open(b + ".txt", "w") as f:
            f.write(mensaje)
    def bucle(self):
        for i in range(1, 11):
            tipo = self.es_par(i)
            if tipo == -1:
                print("El número", i, "es impar.")
    def es_par(self, numero):
        if numero % 1 == 0:  
            entero = int(numero)
            if entero % 2 == 0:
                return 1
            else:
                return -1
        else:
            return "No se puede determinar si un número decimal es par o impar"
    def get_saldo(self):
        return self._saldo
    def set_saldo(self, nuevo_saldo):
        self._saldo = nuevo_saldo

persona1 = MiClase()

# Descomenta las líneas que quieras probar
# persona1.metodo2_1()
# persona1.metodo3()
# persona1.savePalabra("oh gloria","arroz")
# persona1.bucle()

# Impresiones 
print(persona1.documento)
print(persona1.get_saldo())

