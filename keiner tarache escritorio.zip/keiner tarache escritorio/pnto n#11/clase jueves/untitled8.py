import random

class MiClase:
    def __init__(self, documento, saldo_inicial):
        self.documento = documento
        self.__saldo = saldo_inicial
    
    def settSaldo(self, newSaldo): 
        self.__saldo = newSaldo 

    def gettSaldo(self):
        return self.__saldo
        
    def retiro(self, saldoRetirado):
        if saldoRetirado > self.__saldo: 
            self.impriir("No tienes suficiente dinero")
        elif saldoRetirado <= self.__saldo : 
            self.__saldo -= saldoRetirado

    def verSaldo(self): 
        print(f"Saldo actual para {self.documento}: {self.__saldo}")

    def agregarInteres(self, tasa_interes):
        interes = self.__saldo * (tasa_interes / 100)
        self.__saldo += interes
        print(f"Se ha aplicado un interés del {tasa_interes}% al saldo. Nuevo saldo para {self.documento}: {self.__saldo}")

    def impriir(self, mensaje):
        print(mensaje)

u =[]
persona1 = MiClase("123", 200)
persona2 = MiClase("456", 350)
u.append(persona1)
u.append(persona2)
i=0
i=int(input("0. persona1  1. persona2:"))
u[i].verSaldo()
u[i].settSaldo(int(input("ingrese el dinero:")))
u[i].verSaldo()
u[i].agregarInteres(5)  # Agrega un interés del 5%
u[i].verSaldo()
u[i].retiro(int(input("ingrese el dinero a retirar: ")))
u[i].verSaldo()
