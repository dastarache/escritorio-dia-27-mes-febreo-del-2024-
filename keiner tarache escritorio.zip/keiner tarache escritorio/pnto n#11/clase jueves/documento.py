class MiClase:
    def __init__(self):
      self.documento=1120472341
    SALARIO_MINIMO = 10000000  

    def metodo1(self):
        return 0
    def metodo2(self):
        return 1
    def metodo2_1(self):
        numero = float(input("Agrega un número: ")) 
        return numero
    def metodo3(self):
        a = self.metodo1()
        b = self.metodo2()
        c = self.metodo2_1()
        salario = a + b + c
        if salario >= self.SALARIO_MINIMO:
            mensaje = "¡Felicidades! Ganas más del salario mínimo."
        else:
            mensaje = "Ganas menos del salario mínimo."
        return salario, mensaje
    
    def savePalabra(self, mensaje, b):
        f = open(b + ".txt", "w")
        f.write(mensaje)
        f.close()

    def bucle(self):
        for i in range(1, 11):
            tipo = self.es_par(i)
            if tipo == -1:
                print("El número", i, "es impar.")
    
    def es_par(self, numero):
        if numero % 1 == 0:  
            entero = int(numero)
            if entero % 2 == 0:
                return 1
            else:
                return -1
        else:
            return "No se puede determinar si un número decimal es par o impar"
# -------------------------------
persona1 = MiClase()
# Descomenta las líneas que quieras probar
# persona1.metodo2_1()
# persona1.metodo3()
# persona1.savePalabra("oh gloria","arroz")
persona1.bucle()
print(persona1.documento)
