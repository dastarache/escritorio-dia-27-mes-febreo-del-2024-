import random

class MiClase:
    def __init__(self):
        self.documento = random.randint(1, 100)
        self._saldo = 100  # Saldo inicial de 100
        self.SALARIO_MINIMO = 10000000  

    def metodo1(self):
        return 0

    def metodo2(self):
        return 1

    def metodo2_1(self):
        numero = float(input("Agrega un número: ")) 
        return numero

    def metodo3(self):
        a = self.metodo1()
        b = self.metodo2()
        c = self.metodo2_1()
        salario = a + b + c
        if salario >= self.SALARIO_MINIMO:
            mensaje = "¡Felicidades! Ganas más del salario mínimo."
        else:
            mensaje = "Ganas menos del salario mínimo."
        return salario, mensaje

    def savePalabra(self, mensaje, b):
        with open(b + ".txt", "w") as f:
            f.write(mensaje)

    def bucle(self):
        for i in range(1, 11):
            tipo = self.es_par(i)
            if tipo == -1:
                print("El número", i, "es impar.")

    def es_par(self, numero):
        if numero % 1 == 0:  
            entero = int(numero)
            if entero % 2 == 0:
                return 1
            else:
                return -1
        else:
            return "No se puede determinar si un número decimal es par o impar"

    def get_saldo(self):
        return self._saldo

    def set_saldo(self, nuevo_saldo):
        self._saldo = nuevo_saldo

    def retirar_saldo(self, cantidad):
        if cantidad > self._saldo:
            print("No tienes tanta plata pobre.")
        else:
            self._saldo -= cantidad
            print(" Saldo restante:", self._saldo)

persona1 = MiClase()

# Impresiones iniciales
print("Documento:", persona1.documento)
print("Saldo inicial:", persona1.get_saldo())


while persona1.get_saldo() > 0:
    cantidad_retiro = float(input("Ingrese el retiro: "))
    if cantidad_retiro == 0:
        break
    persona1.retirar_saldo(cantidad_retiro)
