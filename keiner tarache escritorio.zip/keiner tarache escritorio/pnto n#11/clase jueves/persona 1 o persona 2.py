import random

class MiClase:
    def __init__(self, documento, saldo_inicial):
        self.documento = documento
        self.__saldo = saldo_inicial
    
    def settSaldo(self, newSaldo): 
        self.__saldo = newSaldo 

    def gettSaldo(self):
        return self.__saldo
        
    def retiro(self, saldoRetirado):
        if saldoRetirado > self.__saldo: 
            self.impriir(" no tienes todo ese dinero que pasa master ")
        elif saldoRetirado <= self.__saldo : self.__saldo -= saldoRetirado

    def verSaldo(self): 
        print(f"Saldo actual para {self.documento}: {self.__saldo}")

    def impriir(self, mensaje):
        print(mensaje)

u =[]
persona1 = MiClase("123", 100)
u.append(persona1)
u[0].verSaldo()
u[0].retiro(int(input("ingrese el dinero a retirar")))
u[0].verSaldo()

#persona1 = MiClase("123", 100)
#persona2 = MiClase("456", 200)
#persona3 = MiClase("789", 300) 

#while True:
  #  print("\nElige una persona:")
   # print("1. Persona 1")
    #print("2. Persona 2")
   # print("3. Persona 3")
    #print("0. Salir")

    #opcion = int(input("Ingresa la opcion (o ingresa 0 para salir): "))

    #if opcion == 0:
      #  print("Saliendo del programa.")
     #   break

    #persona_actual = None

    #if opcion == 1:
       # persona_actual = persona1
    #elif opcion == 2:
      #  persona_actual = persona2
    #elif opcion == 3:  # Selección para persona 3
     #   persona_actual = persona3
    #else:
        #print("Opción no válida. Ingresa 1, 2, 3 o 0 para salir.")
        #continue

    #while True:
     #   persona_actual.verSaldo()  
      #  monto_retiro = int(input("cuanto retira socio (o ingresa 0 para cambiar de persona): "))

       # if monto_retiro == 0:
        #    print("Cambiando de persona.")
         #   break
        
        #persona_actual.retiro(monto_retiro)
