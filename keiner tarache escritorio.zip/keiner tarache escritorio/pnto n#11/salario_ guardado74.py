class MiClase:
    SALARIO_MINIMO = 10000000  
    def metodo1(self):
        return 0
    def metodo2(self):
        return 1
    def metodo2_1(self):
        numero = float(input("Agrega un número: "))  # Cambiado a float para manejar números decimales
        return numero
    def metodo3(self):
        a = self.metodo1()
        b = self.metodo2()
        c = self.metodo2_1()
        salario = a + b + c
        if salario >= self.SALARIO_MINIMO:
            mensaje = "¡Felicidades! Ganas más del salario mínimo."
        else:
            mensaje = "Ganas menos del salario mínimo."
        return salario, mensaje
    def savePalabra(self, mensaje, b):
        f = open(b + ".txt", "w")
        f.write(mensaje)
        f.close()
    def bucle(self):
        contador_archivos = 0
        for i in range(1, 11):
            self.savePalabra("Archivo " + str(i), "archivo" + str(i))
            contador_archivos += 1
            print("Se ha creado el archivo número", contador_archivos)
    def es_par(self, numero):
        # Convertimos el número a entero para verificar si es par o impar
        entero = int(numero)
        if entero % 2 == 0:
            return 1
        else:
            return -1
# -------------------------------
nuevaInstancia = MiClase()
# Descomenta las líneas que quieras probar
# nuevaInstancia.metodo2_1()
# nuevaInstancia.metodo3()
# nuevaInstancia.savePalabra("oh gloria","arroz")
# nuevaInstancia.bucle()
numero = float(input("Ingresa un número: "))  # Cambiado a float para manejar números decimales
resultado = nuevaInstancia.es_par(numero)
print("El resultado es:", resultado)
